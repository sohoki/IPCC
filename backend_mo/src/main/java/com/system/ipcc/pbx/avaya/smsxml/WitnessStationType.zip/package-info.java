@javax.xml.bind.annotation.XmlSchema(namespace = "http://xml.avaya.com/sms")
package com.system.ipcc.pbx.avaya.smsxml;
